package com.example.galaxyunderchaos.block;

import com.mojang.serialization.MapCodec;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.tags.BlockTags;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.LevelReader;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.GrowingPlantHeadBlock;
import net.minecraft.world.level.block.NetherVines;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.shapes.VoxelShape;

public class TythonGrass extends GrowingPlantHeadBlock {
    public static final MapCodec<TythonGrass> CODEC = simpleCodec(TythonGrass::new);
    public static final VoxelShape SHAPE = Block.box(1.0D, 0.0D, 1.0D, 15.0D, 16.0D, 15.0D);
    public static final int MAX_AGE = 8;
    private static final double GROWTH_PROBABILITY = 0.01D;

    public TythonGrass(Properties properties) {
        super(properties, Direction.UP, SHAPE, false, GROWTH_PROBABILITY);
    }

    @Override
    public MapCodec<TythonGrass> codec() {
        return CODEC;
    }

    @Override
    public BlockState getStateForPlacement(LevelAccessor level) {
        return this.defaultBlockState().setValue(AGE, level.getRandom().nextInt(MAX_AGE));
    }

    @Override
    public boolean isRandomlyTicking(BlockState state) {
        return state.getValue(AGE) < MAX_AGE;
    }

    @Override
    public BlockState getMaxAgeState(BlockState state) {
        return state.setValue(AGE, MAX_AGE);
    }

    @Override
    public boolean isMaxAge(BlockState state) {
        return state.getValue(AGE) == MAX_AGE;
    }

    @Override
    protected int getBlocksToGrowWhenBonemealed(RandomSource random) {
        return NetherVines.getBlocksToGrowWhenBonemealed(random);
    }

    @Override
    public void performBonemeal(ServerLevel level, RandomSource random, BlockPos pos, BlockState state) {
        BlockPos growPos = pos.relative(this.growthDirection);
        int newAge = Math.min(state.getValue(AGE) + 1, MAX_AGE);
        int blocksToGrow = this.getBlocksToGrowWhenBonemealed(random);

        for (int i = 0; i < blocksToGrow && this.canGrowInto(level.getBlockState(growPos)); ++i) {
            level.setBlockAndUpdate(growPos, state.setValue(AGE, newAge));
            growPos = growPos.relative(this.growthDirection);
            newAge = Math.min(newAge + 1, MAX_AGE);
        }
    }

    @Override
    protected boolean canGrowInto(BlockState state) {
        return NetherVines.isValidGrowthState(state);
    }

    @Override
    protected Block getBodyBlock() {
        return null;
    }

    @Override
    public boolean canSurvive(BlockState state, LevelReader level, BlockPos pos) {
        BlockPos belowPos = pos.relative(this.growthDirection.getOpposite());
        BlockState belowState = level.getBlockState(belowPos);
        Block belowBlock = belowState.getBlock();
        return this.canAttachTo(belowState) && (belowBlock == this.getHeadBlock() || belowBlock == this.getBodyBlock() || belowState.is(BlockTags.DIRT));
    }
}