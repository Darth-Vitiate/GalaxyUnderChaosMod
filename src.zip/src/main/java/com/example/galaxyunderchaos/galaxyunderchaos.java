package com.example.galaxyunderchaos;

import com.example.galaxyunderchaos.block.*;
import com.mojang.logging.LogUtils;
import net.minecraft.client.Minecraft;
import net.minecraft.core.registries.Registries;
import net.minecraft.world.food.FoodProperties;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.Item;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.event.server.ServerStartingEvent;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.ModLoadingContext;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.config.ModConfig;
import net.minecraftforge.fml.event.lifecycle.FMLClientSetupEvent;
import net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;
import org.slf4j.Logger;

@Mod(galaxyunderchaos.MODID)
public class galaxyunderchaos {
    public static final String MODID = "galaxyunderchaos";
    private static final Logger LOGGER = LogUtils.getLogger();
    public static final DeferredRegister<Block> BLOCKS = DeferredRegister.create(ForgeRegistries.BLOCKS, MODID);
    public static final DeferredRegister<Item> ITEMS = DeferredRegister.create(ForgeRegistries.ITEMS, MODID);
    public static final DeferredRegister<CreativeModeTab> CREATIVE_MODE_TABS = DeferredRegister.create(Registries.CREATIVE_MODE_TAB, MODID);

    public static final RegistryObject<Block> FORCE_STONE = BLOCKS.register("force_stone", ForceStone::new);
    public static final RegistryObject<Item> FORCE_STONE_ITEM = ITEMS.register("force_stone", () -> new BlockItem(FORCE_STONE.get(), new Item.Properties()));

    public static final RegistryObject<Block> FORCE_STONE_PILLAR = BLOCKS.register("force_stone_pillar", ForceStonePillar::new);
    public static final RegistryObject<Item> FORCE_STONE_PILLAR_ITEM = ITEMS.register("force_stone_pillar", () -> new BlockItem(FORCE_STONE_PILLAR.get(), new Item.Properties()));

    public static final RegistryObject<Block> FORCE_STONE_HOLOBOOK = BLOCKS.register("force_stone_holobook", ForceStoneHolobook::new);
    public static final RegistryObject<Item> FORCE_STONE_HOLOBOOK_ITEM = ITEMS.register("force_stone_holobook", () -> new BlockItem(FORCE_STONE_HOLOBOOK.get(), new Item.Properties()));


    public static final RegistryObject<Block> FORCE_STONE_STAIRS = BLOCKS.register("force_stone_stairs", () -> new ForceStoneStairs(FORCE_STONE.get().defaultBlockState()));
    public static final RegistryObject<Item> FORCE_STONE_STAIRS_ITEM = ITEMS.register("force_stone_stairs", () -> new BlockItem(FORCE_STONE_STAIRS.get(), new Item.Properties()));

    public static final RegistryObject<Block> FORCE_STONE_SLAB = BLOCKS.register("force_stone_slab", ForceStoneSlab::new);
    public static final RegistryObject<Item> FORCE_STONE_SLAB_ITEM = ITEMS.register("force_stone_slab", () -> new BlockItem(FORCE_STONE_SLAB.get(), new Item.Properties()));


    public static final RegistryObject<Block> DARK_FORCE_STONE = BLOCKS.register("dark_force_stone", DarkForceStone::new);
    public static final RegistryObject<Item> DARK_FORCE_STONE_ITEM = ITEMS.register("dark_force_stone", () -> new BlockItem(DARK_FORCE_STONE.get(), new Item.Properties()));

    public static final RegistryObject<Block> DARK_FORCE_STONE_PILLAR = BLOCKS.register("dark_force_stone_pillar", DarkForceStonePillar::new);
    public static final RegistryObject<Item> DARK_FORCE_STONE_PILLAR_ITEM = ITEMS.register("dark_force_stone_pillar", () -> new BlockItem(DARK_FORCE_STONE_PILLAR.get(), new Item.Properties()));

    public static final RegistryObject<Block> DARK_FORCE_STONE_HOLOBOOK = BLOCKS.register("dark_force_stone_holobook", DarkForceStoneHolobook::new);
    public static final RegistryObject<Item> DARK_FORCE_STONE_HOLOBOOK_ITEM = ITEMS.register("dark_force_stone_holobook", () -> new BlockItem(DARK_FORCE_STONE_HOLOBOOK.get(), new Item.Properties()));


    public static final RegistryObject<Block> DARK_FORCE_STONE_STAIRS = BLOCKS.register("dark_force_stone_stairs", () -> new DarkForceStoneStairs(DARK_FORCE_STONE.get().defaultBlockState()));
    public static final RegistryObject<Item> DARK_FORCE_STONE_STAIRS_ITEM = ITEMS.register("dark_force_stone_stairs", () -> new BlockItem(DARK_FORCE_STONE_STAIRS.get(), new Item.Properties()));

    public static final RegistryObject<Block> DARK_FORCE_STONE_SLAB = BLOCKS.register("dark_force_stone_slab", DarkForceStoneSlab::new);
    public static final RegistryObject<Item> DARK_FORCE_STONE_SLAB_ITEM = ITEMS.register("dark_force_stone_slab", () -> new BlockItem(DARK_FORCE_STONE_SLAB.get(), new Item.Properties()));

    public static final RegistryObject<Item> SHUURA = ITEMS.register("shuura", () -> new Item(new Item.Properties().food(new FoodProperties.Builder()
            .alwaysEdible().nutrition(6).saturationModifier(2f).build())));
    public static final RegistryObject<Block> ANCIENT_FORCE_STONE = BLOCKS.register("ancient_force_stone", AncientForceStone::new);
    public static final RegistryObject<Item> ANCIENT_FORCE_STONE_ITEM = ITEMS.register("ancient_force_stone", () -> new BlockItem(ANCIENT_FORCE_STONE.get(), new Item.Properties()));
    public static final RegistryObject<Block> ANCIENT_FORCE_STONE_CRACKED = BLOCKS.register("ancient_force_stone_cracked", AncientForceStoneCracked::new);
    public static final RegistryObject<Item> ANCIENT_FORCE_STONE_CRACKED_ITEM = ITEMS.register("ancient_force_stone_cracked", () -> new BlockItem(ANCIENT_FORCE_STONE_CRACKED.get(), new Item.Properties()));
    public static final RegistryObject<Block> ANCIENT_FORCE_STONE_PILLAR = BLOCKS.register("ancient_force_stone_pillar", AncientForceStonePillar::new);
    public static final RegistryObject<Item> ANCIENT_FORCE_STONE_PILLAR_ITEM = ITEMS.register("ancient_force_stone_pillar", () -> new BlockItem(ANCIENT_FORCE_STONE_PILLAR.get(), new Item.Properties()));
    public static final RegistryObject<Block> ANCIENT_FORCE_STONE_HOLOBOOK = BLOCKS.register("ancient_force_stone_holobook", AncientForceStoneHolobook::new);
    public static final RegistryObject<Item> ANCIENT_FORCE_STONE_HOLOBOOK_ITEM = ITEMS.register("ancient_force_stone_holobook", () -> new BlockItem(ANCIENT_FORCE_STONE_HOLOBOOK.get(), new Item.Properties()));
    public static final RegistryObject<Block> ANCIENT_FORCE_STONE_STAIRS = BLOCKS.register("ancient_force_stone_stairs", () -> new AncientForceStoneStairs(ANCIENT_FORCE_STONE.get().defaultBlockState()));
    public static final RegistryObject<Item> ANCIENT_FORCE_STONE_STAIRS_ITEM = ITEMS.register("ancient_force_stone_stairs", () -> new BlockItem(ANCIENT_FORCE_STONE_STAIRS.get(), new Item.Properties()));

    public static final RegistryObject<Block> ANCIENT_FORCE_STONE_SLAB = BLOCKS.register("ancient_force_stone_slab", AncientForceStoneSlab::new);
    public static final RegistryObject<Item> ANCIENT_FORCE_STONE_SLAB_ITEM = ITEMS.register("ancient_force_stone_slab", () -> new BlockItem(ANCIENT_FORCE_STONE_SLAB.get(), new Item.Properties()));


    public static final RegistryObject<Block> TYTHON_GRASS = BLOCKS.register("tython_grass",
            () -> new TythonGrass(BlockBehaviour.Properties.ofFullCopy(Blocks.GRASS_BLOCK).strength(0.5F))
    );

    public static final RegistryObject<Item> TYTHON_GRASS_ITEM = ITEMS.register("tython_grass",
            () -> new BlockItem(TYTHON_GRASS.get(), new Item.Properties()));

    public static final RegistryObject<CreativeModeTab> GALAXY_UNDER_CHAOS_TAB = CREATIVE_MODE_TABS.register("galaxy_under_chaos", () -> CreativeModeTab.builder()
            .withTabsBefore(CreativeModeTabs.COMBAT)
            .icon(() -> FORCE_STONE.get().asItem().getDefaultInstance())  // Use asItem() to get the item form
            .displayItems((parameters, output) -> {
                output.accept(FORCE_STONE.get().asItem());
                output.accept(FORCE_STONE_HOLOBOOK.get().asItem());
                output.accept(FORCE_STONE_PILLAR.get().asItem());
                output.accept(FORCE_STONE_STAIRS.get().asItem());
                output.accept(FORCE_STONE_SLAB.get().asItem());
                output.accept(DARK_FORCE_STONE.get().asItem());
                output.accept(DARK_FORCE_STONE_HOLOBOOK.get().asItem());
                output.accept(DARK_FORCE_STONE_PILLAR.get().asItem());
                output.accept(DARK_FORCE_STONE_STAIRS.get().asItem());
                output.accept(DARK_FORCE_STONE_SLAB.get().asItem());
                output.accept(ANCIENT_FORCE_STONE.get().asItem());
                output.accept(ANCIENT_FORCE_STONE_HOLOBOOK.get().asItem());
                output.accept(ANCIENT_FORCE_STONE_PILLAR.get().asItem());
                output.accept(ANCIENT_FORCE_STONE_CRACKED.get().asItem());
                output.accept(ANCIENT_FORCE_STONE_STAIRS.get().asItem());
                output.accept(ANCIENT_FORCE_STONE_SLAB.get().asItem());
                output.accept(TYTHON_GRASS.get().asItem());
            }).build());
    public static final RegistryObject<CreativeModeTab> GALAXY_UNDER_CHAOS_ITEMS_TAB = CREATIVE_MODE_TABS.register("galaxy_under_chaos_items", () -> CreativeModeTab.builder()
            .icon(() -> SHUURA.get().getDefaultInstance())
            .displayItems((parameters, output) -> {
                output.accept(SHUURA.get());
            }).build());

    public galaxyunderchaos() {
        IEventBus modEventBus = FMLJavaModLoadingContext.get().getModEventBus();
        modEventBus.addListener(this::commonSetup);
        BLOCKS.register(modEventBus);
        ITEMS.register(modEventBus);
        CREATIVE_MODE_TABS.register(modEventBus);
        MinecraftForge.EVENT_BUS.register(this);

        ModLoadingContext.get().registerConfig(ModConfig.Type.COMMON, Config.SPEC);
    }

    private void commonSetup(final FMLCommonSetupEvent event) {
        LOGGER.info("HELLO FROM COMMON SETUP");

        if (Config.logDirtBlock)
            LOGGER.info("DIRT BLOCK >> {}", ForgeRegistries.BLOCKS.getKey(Blocks.DIRT));

        LOGGER.info(Config.magicNumberIntroduction + Config.magicNumber);

        Config.items.forEach((item) -> LOGGER.info("ITEM >> {}", item.toString()));
    }

    public static void register(IEventBus eventBus) {
        ITEMS.register(eventBus);
        BLOCKS.register(eventBus);
    }

    @SubscribeEvent
    public void onServerStarting(ServerStartingEvent event) {
        LOGGER.info("HELLO from server starting");
    }

    @Mod.EventBusSubscriber(modid = MODID, bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
    public static class ClientModEvents {
        @SubscribeEvent
        public static void onClientSetup(FMLClientSetupEvent event) {
            LOGGER.info("HELLO FROM CLIENT SETUP");
            LOGGER.info("MINECRAFT NAME >> {}", Minecraft.getInstance().getUser().getName());
        }
    }
}